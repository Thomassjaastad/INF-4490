from __future__ import division
import numpy as np
import matplotlib.pyplot as plt 
import itertools
import csv
from datetime import datetime
import time
import random
#Solving Traveling Salesman Problem (TSP) with GeneticAlgorithm and Hillclimbing algo.

with open("european_cities.csv", "r") as f:
	data = list(csv.reader(f, delimiter=';'))

n = 24   #number of cities
data = np.asarray(data)
CitiesDist = data[1 : n + 1, 0 : n] #Skipping "string", name of cities
Cities = np.arange(n)  

CitiesPermute = []
#Making a population of random permutations 
for i in range(20000):
	CitiesPermute.append(np.random.permutation(Cities))
CitiesPermute = np.array(CitiesPermute)

def Fitness(Index, Dist):
	#Want to calculate the distance between n cities and return the total distance
	#Remember to calculate to distance from end to start at the end of loop    
	DistValues = np.zeros(n)
	for i in range(n - 1):
		start = Index[i]
		end = Index[i + 1]
		DistValues[i] = Dist[start, end]  
	DistValuesFinal = Dist[Index[n - 1], Index[0]]
	DistValues[n - 1] = DistValuesFinal
	return 1/np.sum(DistValues), DistValues 

def NormFitness(func, Dist, populationSet):
	SumPopulation = 0
	SumBaldwinian = 0
	Baldwinian = np.zeros(len(populationSet))
	FitnessOne = np.zeros(len(populationSet))
	for i in range(len(populationSet)):
		FitnessOne[i] = func(populationSet[i], CitiesDist)[0]
		Baldwinian[i] = HillClimbing(func, populationSet[i])[2]
		SumPopulation += FitnessOne[i] 
		SumBaldwinian += Baldwinian[i]
	NormalizedFitness = FitnessOne/SumPopulation
	NormalizedBaldwinian = Baldwinian/SumBaldwinian
	return NormalizedFitness, np.sum(NormalizedFitness), FitnessOne, NormalizedBaldwinian 

def TournamentSelection(lamb, k):  #k < lamb. lamb is a subset of population
	current_member = 1
	mating_pool = []
	while current_member <= lamb:
		individuals = random.sample(population, k)    
		EvalFitness = NormFitness(Fitness, CitiesDist, individuals)[3]   		
		mating_pool.append(individuals[np.argmax(EvalFitness)])
		current_member += 1
	return mating_pool

def TournamentSelection2(lamb, k, Family):  #k < lamb. lamb is a subset of population
	current_member = 1
	mating_pool = []
	while current_member <= lamb:
		individuals = random.sample(Family, k)    
		EvalFitness = NormFitness(Fitness, CitiesDist, individuals)[3]    #Baldwinian		
		mating_pool.append(individuals[np.argmax(EvalFitness)])
		current_member += 1
	return mating_pool

#Make sure that population size is the same. Get rid of bad genotypes to store better genotypes

def PMX(ParentA, ParentB, start, end):
	ParentA = ParentA.tolist()
	ParentB = ParentB.tolist()
	offspring = [None]*len(ParentA)
	offspring[start : end] = ParentA[start : end]

	#A gene in ParentB[step] is occupied by a gene in offspring[step].
	#Take the gene occupied in offspring and locate that specific gene in ParentB.
	#Then place the gene with corresponding index as in ParentB in offspring     

	for step, gene in enumerate(ParentB[start : end]):
		step += start
		#gene from parentB
		if gene not in offspring:
			while offspring[step] != None: 
				step = ParentB.index(ParentA[step])
			offspring[step] = gene
	#The remaining genes in offspring which are empty gets filled with the genes from ParentB
	#offspring consist of a mix of ParentA and ParentB
	for step, gene in enumerate(offspring):
		if gene == None:
			offspring[step] = ParentB[step]
	return offspring

def PMX_pair(ParentA, ParentB):
	half = n//2
	start = np.random.randint(0, half)
	end = np.random.randint(half, n + 1)
	return PMX(ParentA, ParentB, start, end), PMX(ParentB, ParentA, start, end) 

def Mutation(Genotype):
	half = n//2
	start = np.random.randint(0, half)
	end = np.random.randint(half, n + 1)
	if start == end:
		raise ValueError('A and B are equal') 
	Genotype[start : end] = np.flip(Genotype[start : end], 0) #Must be ints 
	return Genotype, start, end 

def HillClimbing(func, CityOrder):
    #Choosing a random set of cities and minimizing distance 
    #Calculating distance from two cities 
    for i in range(10):
        city1 = np.random.randint(n)
        city2 = np.random.randint(n)
        if city1 != city2:
            possibleCityOrder = CityOrder.copy() 
            possibleCityOrder = np.where(possibleCityOrder == city1, -1, possibleCityOrder)    
            possibleCityOrder = np.where(possibleCityOrder == city2, city1, possibleCityOrder)
            possibleCityOrder = np.where(possibleCityOrder == -1, city2 , possibleCityOrder)

            CurrentDistance = func(CityOrder, CitiesDist)
            NewDistance = func(possibleCityOrder, CitiesDist)

            if NewDistance > CurrentDistance:
                CurrentDistance = NewDistance
                CityOrder = possibleCityOrder    
    return CurrentDistance, list(CityOrder), func(list(CityOrder), CitiesDist)[0]

means = []
dev = []
best = []
worst = []
bestMeans = []
MeanFitness = []

#Parameters to be tuned
PopulationSize = 50
subPopulation = 12
runs = 20
generations = 200

Bestgen = np.zeros(PopulationSize)
NewFitness = np.zeros(PopulationSize)

startTime = time.time()
#Solver
#population = CitiesPermute[0 : 1, :]

#Baldwinian = HillClimbing(Fitness, population[0])[2]              #Baldwinian only the fitness 
#Larmarckian = HillClimbing(Fitness, population[0])[1]          #Larmarckian bothe fitness and permutation


for k in range(runs):
	Cit = np.random.shuffle(CitiesPermute)	
	population = CitiesPermute[0 : PopulationSize, :]
	population = list(population)
	for t in range(generations):
		candidate = TournamentSelection(subPopulation, 2)
		#NextGenMutate = np.zeros((subPopulation - 1, n))
		#NextGenMutate2 = np.zeros((subPopulation - 1, n))
		Kidz = []
		for i in range(subPopulation - 1):
			offspring1, offspring2 = PMX_pair(candidate[i], candidate[i + 1])
			offspring1 = Mutation(np.array(offspring1))[0]
			offspring2 = Mutation(np.array(offspring2))[0]			
			Kidz.append(offspring1)
			Kidz.append(offspring2)
		Family = np.append(Kidz, candidate, axis = 0)
		nextgeneration = TournamentSelection2(PopulationSize, 2, list(Family))
		NewFitness = NormFitness(Fitness, CitiesDist, nextgeneration)[2]
		population = nextgeneration
		bestMeans.append(1/np.max(NewFitness))	
	best.append(1/np.max(NewFitness))       
	worst.append(1/np.min(NewFitness))
	means.append(1/np.mean(NewFitness))
	dev.append(np.std(1/NewFitness))

with open('best.txt','w') as f:
	for k in range(runs):
		f.write("best individual of run %d has length %f \n" % (k, best[k]))

with open('worst.txt','w') as f:
	for k in range(runs):
		f.write("worst individual of run %d has length %f \n" % (k, worst[k]))

with open('meansandstd.txt','w') as f:
	for k in range(runs):
		f.write("mean and std of an individual of run %d has value %f, %f \n" % (k, means[k], dev[k]))

with open('averagefitnessoverbestindividual.txt','w') as f:
	for t in range(generations):
		MeanFitness.append(np.mean(bestMeans[t: runs*generations: generations]))
		f.write("average fitness of best individual for each generation %d has value %f \n" % (t, np.mean(bestMeans[t: runs*generations: generations])))
generation = np.linspace(1, generations, generations)
plt.title(r'Average distance over maxdistance of each generation with Baldwinian', fontsize = 18)
plt.xlabel(r'Numb of generations', fontsize = 16)
plt.ylabel(r'Average distance [km]', fontsize = 16)
plt.plot(generation, MeanFitness, '*', label = 'Population Size 10')
plt.show()
endTime = time.time()
#Clock end and printing
print('Runtime for', n, 'cities is', 't =', (endTime - startTime),'s')
