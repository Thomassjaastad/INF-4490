import matplotlib.pyplot as plt
import numpy as np

#10 cities
populationFile1 = open('populationsize10.txt', 'r')
populationFile2 = open('populationsize20.txt', 'r')
populationFile3 = open('populationsize30.txt', 'r')

#24 cities
populationFile4 = open('populationsize10Cities24.txt', 'r')
populationFile5 = open('populationsize50Cities24.txt', 'r')
populationFile6 = open('populationsize200Cities24.txt', 'r')

def GenerationVal(Popfile):  
    value = []
    for line in Popfile:
        words = line.split()
        value.append(float(words[-1]))  
    return value

pop1 = GenerationVal(populationFile1)  
pop2 = GenerationVal(populationFile2) 
pop3 = GenerationVal(populationFile3)

pop4 = GenerationVal(populationFile4)
pop5 = GenerationVal(populationFile5)
pop6 = GenerationVal(populationFile6)

generation = np.linspace(1, len(pop1), len(pop1))
plt.title(r'Average distance over maxdistance of each generation for 10 cities', fontsize = 18)
plt.xlabel(r'Numb of generations', fontsize = 16)
plt.ylabel(r'Average distance [km]', fontsize = 16)
plt.plot(generation, pop1, '*', label = 'Population Size 10')
plt.plot(generation, pop2, 'o', label = 'Population Size 20')
plt.plot(generation, pop3, 's', label = 'Population Size 30')
plt.legend()
plt.show()

plt.title(r'Average distance over maxdistance of each generation for 24 cities', fontsize = 18)
plt.xlabel(r'Numb of generations', fontsize = 16)
plt.ylabel(r'Average distance [km]', fontsize = 16)
plt.plot(generation, pop4, '*', label = 'Population Size 10')
plt.plot(generation, pop5, 'o', label = 'Population Size 50')
plt.plot(generation, pop6, 's', label = 'Population Size 200')
plt.legend()
plt.show()
