"""
    This pre-code is a nice starting point, but you can
    change it to fit your needs.
"""
import numpy as np
class mlp:
    def __init__(self, inputs, targets, nhidden):
        self.inputs = inputs
        self.targets = targets
        self.nhidden = nhidden
        self.beta = 1
        self.eta = 0.1
        self.momentum = 0.0
        self.w = np.random.uniform(-0.7, 0.7, size = (len(inputs[0,:]) + 1, nhidden))          
        self.v = np.random.uniform(-0.7, 0.7, size = (nhidden + 1, len(targets[0, :])))
        

    # You should add your own methods as well!
    def error(self, output, targets, acti, hiddenW, outputW):
        n_vectors = output.shape[0]
        deltaO = np.zeros((n_vectors,outputW.shape[0], outputW.shape[1]))
        deltaH = np.zeros((n_vectors, hiddenW.shape[0], hiddenW.shape[1]))
        errorSum = np.zeros((n_vectors, self.nhidden))
        for n in range(n_vectors):                  #Number of training inputs
            for j in range(self.nhidden):           #Hidden nodes
                for k in range(output.shape[-1]):   #Number of output nodes
                    deltaO[n,j, k] = (output[n, k] - targets[n, k])*output[n, k]*(1 - output[n, k]) 
                    errorSum[n, j] += deltaO[n,j, k]*outputW[j, k]        
                deltaH[n, :, j] = acti[n, j]*(1- acti[n, j])*(errorSum[n, j])
        return deltaO, deltaH
    
    def Sigmoid(self, u):
        return 1/(1 + np.exp(-self.beta*u))

    def earlystopping(self, inputs, targets, valid, validtargets):
        w = self.w 
        v = self.v
        epochs = 50
        for i in range(epochs):
            acc,w,v = (self.train(inputs,targets,w,v))   

            print(acc)
        print('To be implemented')

    def train(self, inputs, targets,w,v):
        
        out, z, w, v, inputs_tot = self.forward(inputs, targets,w,v)
        inputs_tot = inputs_tot.reshape((inputs_tot.shape[0], inputs_tot.shape[1], 1))

        updatev, updatew = self.error(out, targets, z, w, v)
        #print(updatev.shape, z.shape)
        for i in range(inputs.shape[0]):
            for j in range(self.nhidden):
                updatev[i, j, :] = updatev[i, j, :] * z[i, j]
        updatew = updatew *inputs_tot
        
        updatew = np.mean(updatew, axis = 0)
        updatev = np.mean(updatev, axis = 0)
        w -= self.eta*updatew
        v -= self.eta*updatev

        acc = 0
        for i in range(inputs.shape[0]): 
            if np.argmax(out[i]) == np.argmax(targets[i]):
                acc += 1

        return acc/inputs.shape[0], w ,v
    
    def forward(self, inputs, targets,w,v):
        n_vectors = inputs.shape[0]             #224 vectors
        vec_length = inputs.shape[1]            #40 input nodes
        n_targets = self.targets.shape[1]       #8 output nodes
        biasw = -np.c_[np.ones(inputs.shape[0])]
        biasv = -np.c_[np.ones(inputs.shape[0])]

        #print(inputs.shape, biasw.shape, w.shape)
        inputs_tot = np.concatenate((inputs, biasw), axis = 1)

        hidden_layer = np.zeros((n_vectors, self.nhidden))

        z = np.zeros((n_vectors,self.nhidden))
        z_tot = np.concatenate((z, biasv), axis = 1)    

        out = np.zeros((n_vectors, n_targets))
        for n in range(n_vectors):
            for j in range(self.nhidden):
                for i in range(vec_length + 1):
                    hidden_layer[n,j] += inputs_tot[n,i]*self.w[i, j]
                z_tot[n,j] = self.Sigmoid(hidden_layer[n,j])                
            for j in range(n_targets):
                for i in range(self.nhidden + 1):
                    out[n, j] += z_tot[n,i]*self.v[i, j]  
           
        return out, z_tot, w, v, inputs_tot

    def confusion(self, targets, out):
        confusion = np.zeros((out.shape[-1], out.shape[-1]))

        for i in range(out.shape[-1]): 
            confusion[np.argmax(out[i]), np.argmax(targets[i])] += 1
        return confusion/targets.shape[0]
